$('.menu-btn').click(function() {
  $('.menu-btn span').toggleClass('menu-btn-active');
  $('.primary-menu').toggleClass('primary-menu-active');
});
